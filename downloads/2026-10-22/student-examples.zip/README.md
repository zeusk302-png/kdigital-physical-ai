# OpenCV + 웹캠 실습 실습 자료

[course/README.md](course/README.md)부터 읽으세요.
