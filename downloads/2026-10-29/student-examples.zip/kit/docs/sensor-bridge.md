# 센서와 대시보드 연결


## 센서부터 화면까지 세 개의 터미널

10/23 센서 kit와 오늘 dashboard kit는 다른 폴더입니다. 첫 터미널은 dashboard kit에서 서버를 실행하고, 두 번째는 sensor kit에서 실제 USB를 수집하며, 세 번째는 dashboard kit에서 그 파일을 API로 전달합니다. 프런트 원본을 수정할 때만 네 번째 터미널을 엽니다. 창 이름·현재 폴더·실행 역할을 종이에 표시합니다.

### 1. 서버 실행

dashboard kit를 VS Code로 열고 다음을 실행합니다. Python 3.12가 없다면 앞선 수업 설치 안내부터 확인합니다. 새 터미널은 File → Open Folder와 별개로 열 수 있습니다.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend/requirements.txt
.\.venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8895
```

http://127.0.0.1:8895 를 엽니다. 처음에는 빈 화면이 정상입니다. /docs에서 POST /api/events의 요청 필드를 확인합니다. 코드가 저장된 GitHub Pages가 이 Python 서버를 대신 실행하지는 않습니다.

### 2. 실제 수집

sensor kit 터미널에서 Serial Monitor를 닫고 `.\.venv\Scripts\python.exe -m pc.collect --port COM5 --device team01-xiao`를 실행합니다. COM5는 실제 값입니다. runtime/readings.jsonl에 새 줄이 쌓이는지 확인합니다. 탐색기에서 파일 경로를 복사합니다.

### 3. API 전달

dashboard kit의 새 터미널에서 다음 경로를 실제 센서 파일의 절대 경로로 바꿉니다. 공백이 있으면 따옴표를 유지합니다.

```powershell
.\.venv\Scripts\python.exe adapters/forward_jsonl.py "D:\my-sensor\runtime\readings.jsonl" --follow
```

수신 확인 출력과 웹의 기록 증가를 비교합니다. 장치 필터에 team01-xiao, 종류에 distance_cm을 선택합니다. 파일의 event_id를 하나 골라 /api/events 응답·SQLite 저장·화면에서 같은 사건인지 추적합니다. 코드에 적은 임의 기록 몇 개로 센서 연동을 대신하지 않습니다.

## 실패와 복구

센서 수집만 종료하면 API는 계속 응답하지만 새 값이 멈춥니다. 서버를 종료하면 화면 조회도 실패합니다. 두 상태를 다르게 표시하는지 확인합니다. 서버를 재시작하고 동일 파일을 다시 전달했을 때 같은 event_id가 중복 저장되지 않아야 합니다. 같은 ID의 내용을 바꾸면 409 충돌로 중단합니다.

기록이 5000건을 넘으면 조회 한도 안내가 나오므로 시간 범위와 장치를 좁힙니다. 고속 기록을 무제한 화면에 붙이지 않습니다. 실제 장치 미사용 시 실제 YOLO 로그로 같은 경로를 실행하고 센서 연동과 구분합니다.
