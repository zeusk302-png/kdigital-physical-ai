# D05 · 입력 오류와 미측정 값을 구분하기
# ====================================================================
# 이 파일은 사람이 읽는 설명과 컴퓨터가 실행할 코드를 함께 담습니다.
# # 뒤는 주석입니다. 코드에 초록색이 표시되는지는 편집기 설정에 따라 다릅니다.
# 저장: course/advanced/D05_broken.py
# 실행: course 폴더의 터미널에서 python -X utf8 advanced/D05_broken.py
# 편집기에 명령을 적지 않습니다. 코드 수정 후 Ctrl+S로 저장합니다.
# 파일 전체는 실행 가능하며, data와 함수 파일은 advanced 폴더에 함께 둡니다.
# 입력 파일 data는 읽고, 생성 결과는 work에 저장합니다.
#
# 무엇을 배우나요?
# 숫자 0은 실제로 측정한 값일 수 있지만 빈칸은 측정값이 없는 상태일 수 있습니다. 잘못된 글자를 0으로 바꾸면 합계와
# 평균이 왜곡됩니다. 정상 값·미측정·잘못된 값을 구분해 보관합니다.
#
# 구성요소와 기호
# strip: 앞뒤 공백을 제거한 새 문자열입니다. 원문은 별도로 보관할 수 있습니다.
# try와 except: 변환을 시도하고 예상한 오류를 잡습니다. 모든 오류를 무조건 숨기지 않습니다.
# raise ValueError: 입력 약속을 위반했음을 호출한 코드에 알립니다.
# math.isfinite: float 변환에 성공해도 NaN·Infinity는 정상적인 유한 측정값인지 따로 확인합니다.
# None과 0: None은 측정하지 않은 상태, 0은 수치입니다. 평균 계산에서 None은 개수에 포함하지 않습니다.
#
# 이 단원의 첫 예제 실행을 따라가기
# 공백만 있는 입력을 strip하면 빈 문자열이 됩니다. 이 값은 None으로 보관합니다. "0"은 0.0으로 변환합니다.
# "bad"는 변환 오류, "NaN"은 유한성 검사 오류로 별도 기록합니다.
#
# 한 부분 바꾸고 확인하기
# 두 번째 예제의 입력 목록에 " -3.5 "와 "Infinity"를 추가하세요. 첫 값은 측정값, 두 번째는 오류로
# 구분되는지 확인하세요.

# D05 · 숫자 변환 실패와 미측정 분리
# 파일 전체를 복사해 UTF-8로 저장합니다. # 뒤의 글은 실행하지 않는 주석입니다.
# 배울 내용: strip, 예외 처리, None, 튜플
# 실행: course 폴더에서 python -X utf8 advanced/D05_broken.py
# print(...)의 괄호는 출력할 값을 묶고, 문자열 양끝 따옴표는 글자의 범위를 나타냅니다.
# 먼저 입력값을 보고 결과를 예상한 다음, 실제 출력과 비교하세요.

def parse_temperature(raw):
    # (값, 문제)를 한 쌍으로 반환합니다. 문제가 없으면 두 번째 값은 None입니다.
    text = raw.strip()
    if text == "":
        return None, None  # 빈칸은 미측정이지 입력 오류가 아닙니다.
    try:
        value = float(text)
    except ValueError:
        return None, None
    return value, None

for raw in ["22.5", "0", "", "오류"]:
    value, issue = parse_temperature(raw)
    if issue is not None:
        print(f"[{raw}]: 입력 오류")
    elif value is None:
        print(f"[{raw}]: 미측정")
    else:
        print(f"[{raw}]: {value}")
# 빈칸과 '오류'를 모두 None 하나로 반환하면 원인을 잃습니다.
# 이 단계에서는 온도의 현실적 범위까지 검사하지 않습니다.
# 직접 작성: '-2.5'와 ' 24 '도 숫자로 읽히는지 확인하세요.
