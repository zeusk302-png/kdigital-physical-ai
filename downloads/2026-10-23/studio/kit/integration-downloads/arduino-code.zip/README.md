# 통합·단품 코드 사용 안내

firmware/P01/P01.ino는 목요일에 사용할 기본 통합 회로입니다. P02/P03은 회로 전체를 교체한 뒤 사용합니다. .ino와 같은 폴더의 pins.h·protocol.h를 함께 유지합니다. Arduino Uno·실제 COM 포트를 선택하고 검증 → 업로드 → 시리얼 모니터115200·새 줄 설정을 사용합니다.

P01은 DHT sensor library1.4.7, Adafruit Unified Sensor1.1.15, hd44780 1.3.2가 필요합니다. P02/P03은 추가 라이브러리 없음, P04는 Servo1.3.0입니다. 원본 자료의 각 핀·전원·저항 조건을 먼저 확인합니다.

P04는 외부전원이 없어 MOTOR_POWER_CONFIRMED=false를 유지합니다. 오늘 모터 연결·통전·구동을 하지 않습니다. reference-sketches의 K00~K26은 기존9600 단품 참조 코드입니다. 모델/전원 조건을 확인하기 전 코드를 업로드해 동작시키지 않습니다. 특히 K18/K19 모터 코드는 별도전원 조건을 충족하기 전 실행하지 않습니다.

통합 스케치4개는 컴파일을 확인했으며 실제 배선·업로드·전류·동작은 별도 확인 대상입니다. 단품27개는 기존 참조를 보존했습니다. 실습 그림과 각 핀 표는 아래 수업 화면에서 확인합니다.

https://zeusk302-png.github.io/kdigital-physical-ai/downloads/2026-10-23/studio/kit/integration/index.html
