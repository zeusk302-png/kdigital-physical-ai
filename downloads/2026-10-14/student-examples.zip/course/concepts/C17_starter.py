# =====================================================================
# C17 · 입력부터 요약까지 종합하기 / 예제 2: 측정 숫자 요약 프로그램
# =====================================================================
# 무엇을 배우나요? 문제를 입력·처리·출력으로 나누고 앞에서 배운 개념을 연결합니다. 종료, 잘못된 입력, 빈 자료도 정상 동작에 포함합니다.
# 이 파일은 설명과 실행 코드를 함께 읽는 학습용 Python 파일입니다.
# # 뒤의 내용은 주석입니다. 실행되지 않으며 편집기에 따라 색이 다릅니다.
# 저장: course/concepts/C17_02_normal.py · UTF-8 · .py.txt가 아닌 .py
# 실행: course 폴더의 터미널에서 python -X utf8 concepts/C17_02_normal.py
# 터미널 명령과 예상 출력은 이 파일에 붙여 넣지 않습니다.
# 괄호 ()는 함수에 전달할 값을 묶습니다. 따옴표는 문자열의 범위를 나타냅니다.
# 코드는 위에서 아래로 실행됩니다. 먼저 결과를 예상한 뒤 실행하세요.
# ---------------------------------------------------------------------
def average(numbers):
    """숫자 목록의 평균을 반환합니다. 빈 목록은 None을 반환합니다."""
    if len(numbers) == 0:
        return None
    return sum(numbers) / len(numbers)

numbers = []
while True:
    raw = input("숫자(done 종료): ")
    line = raw.strip().lower()
    if line == "done":
        break
    try:
        number = float(line)
    except ValueError:
        print("숫자가 아니라서 건너뜁니다.")
        continue
    # TODO: 입력받은 숫자를 목록에 추가하세요. 항상 0을 넣으면 실제 값을 잃습니다.
    pass

if len(numbers) == 0:
    print("입력된 숫자가 없습니다.")
else:
    mean = average(numbers)
    largest = max(numbers)
    print(f"개수 {len(numbers)}개, 평균 {mean:.2f}, 최댓값 {largest}")
# 숫자 0은 정상 입력입니다. 빈 목록과 혼동하지 않습니다.
# 추가 도전: float('nan')처럼 변환되지만 측정값으로 쓰기 어려운 값을 거절하세요.
# 이 예제는 장비 연결 없이 입력과 집계를 배우는 프로그램입니다.
