# Sensor checker

Run checker.
